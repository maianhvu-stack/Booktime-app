import Link from "next/link"
import { getTeamMembers } from "@/lib/db/team-members"
import { SearchClient } from "@/components/search-client"

export default async function HomePage() {
  const teamMembers = await getTeamMembers()

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-semibold">TeamBook</h1>
            <nav className="flex items-center gap-6">
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                About
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Contact
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16 md:py-24">
        <div className="max-w-3xl mx-auto text-center space-y-6">
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight text-balance">Book Time with Our Expert Team</h2>
          <p className="text-lg text-muted-foreground text-balance">
            Find the right expert and schedule a meeting in seconds. No back-and-forth emails required.
          </p>
        </div>
      </section>

      <SearchClient teamMembers={teamMembers} />
    </div>
  )
}
