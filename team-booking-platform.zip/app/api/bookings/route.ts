import { NextResponse } from "next/server"
import { createBooking, type CreateBookingData } from "@/lib/db/bookings"

export async function POST(request: Request) {
  try {
    const body: CreateBookingData = await request.json()

    const { booking, error } = await createBooking(body)

    if (error || !booking) {
      return NextResponse.json({ error: error || "Failed to create booking" }, { status: 400 })
    }

    return NextResponse.json(booking, { status: 201 })
  } catch (error) {
    console.error("[v0] API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
